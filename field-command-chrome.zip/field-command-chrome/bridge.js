// ==UserScript==
// @name         Field Command — AWBW bridge
// @namespace    field-command-awbw-bridge
// @version      0.5.0
// @description  GBA-style interface for your existing AWBW account and games. All artwork included.
// @match        https://awbw.amarriner.com/game.php*
// @match        https://awbw.amarriner.com/yourgames.php*
// @grant        none
// @inject-into  page
// @run-at       document-start
// @noframes
// ==/UserScript==
(()=>{
const FC_INSPECTION=(()=>{// Read-only evidence sanitizers shared by the userscript build and local tests.
const secretKey=/auth|token|secret|password|cookie|session|csrf|nonce|signature|hash|email|chat|message|private|account|key/i;
const safeField=/^(?:id|x|y|hp|health|fuel|ammo|army|owner|type|name|capture|movement|moved|attacked|finished|version|turn|day|funds|weather|fog|success|error|status|result|action|unit|player|gameId|stateTime|playerID|unitID|buildingID|buildingInfo|newUnit|newIncome|nextPId|nextFunds|attacker|defender|err|Move|Fire|Capt|Build|NextTurn|End|coordinates|destination|path|moves|game|gameData|game_data|data|response|state|units|players|map|terrain|buildings|properties|active_player|current_turn|current_player|(?:games?|units?|players?|maps?|terrain|buildings?)_(?:id|x|y|hp|hit_points|players_id|team|health|fuel|ammo|army|owner|type|name|capture|movement|movement_points|moved|attacked|finished|version|turn|day|funds|fog))$/i;
const safeRequestField=/^(?:x|y|action|type|destination|path|moves|turn|day|gameId|stateTime|playerID|unitID|buildingID|attacker|defender|(?:games?|units?|players?|turn)_(?:id|x|y))$/i;
const enumValue=/^(?:move|fire|capt|end|nextturn|attack|capture|wait|end[ _-]?turn|build|buy|purchase|infantry|mech|tank|md[ ._-]?tank|neotank|megatank|recon|apc|artillery|rocket|missile|anti[ -]?air|b[ -]?copter|t[ -]?copter|fighter|bomber|cruiser|battleship|lander|sub|carrier|plain|forest|mountain|road|bridge|sea|river|city|base|airport|port|hq|snow|rain|clear|fog|success|error|ok|os|ge|bm|yc|bh)$/i;
function schema(value,depth=0){
 if(depth>4)return '…';
 if(Array.isArray(value))return{array:value.length?schema(value[0],depth+1):'empty'};
 if(value&&typeof value==='object'){const out={};for(const key of Object.keys(value).slice(0,80)){if(secretKey.test(key))continue;out[key]=schema(value[key],depth+1);}return out;}
 return value===null?'null':typeof value;
}
function responseSample(value,depth=0){
 if(depth>8)return undefined;
 if(value===null||typeof value==='boolean')return value;
 if(typeof value==='number')return Number.isFinite(value)?value:undefined;
 if(typeof value==='string'){if(/^-?\d+(?:\.\d+)?$/.test(value)&&value.length<16)return value;if(enumValue.test(value))return value;return undefined;}
 if(Array.isArray(value))return value.slice(0,400).map(item=>responseSample(item,depth+1)).filter(item=>item!==undefined);
 if(value&&typeof value==='object'){const out={};for(const key of Object.keys(value).slice(0,500)){if(secretKey.test(key)||(!safeField.test(key)&&!/^\d{1,12}$/.test(key)))continue;const item=responseSample(value[key],depth+1);if(item!==undefined)out[key]=item;}return out;}
 return undefined;
}
function bodyObject(body){
 try{if(body instanceof URLSearchParams)return Object.fromEntries(body);if(typeof FormData!=='undefined'&&body instanceof FormData)return Object.fromEntries([...body].filter(([,v])=>typeof v==='string'));if(typeof body==='string'){return body.trim().startsWith('{')?JSON.parse(body):Object.fromEntries(new URLSearchParams(body));}}catch{}
 return {};
}
function requestSample(body,url){
 const out={};const values={...Object.fromEntries(new URL(url,'https://awbw.amarriner.com').searchParams),...bodyObject(body)};
 for(const[key,value]of Object.entries(values)){if(secretKey.test(key)||!safeRequestField.test(key))continue;const item=responseSample(value);if(item!==undefined)out[key]=item;}
 return out;
}
;return {schema,responseSample,requestSample};})();

const FC_ORDERS=(()=>{// The bridge owns authority. The handheld can request previews, never raw wire messages.
function createOrderGate(adapter, {now=()=>Date.now(), id=()=>crypto.randomUUID(), timeout=15000}={}) {
 let enabled=false, revision=0, proposal=null, pending=null, locked=false;
 const consumed=new Set();
 function tick(){if(pending&&now()-pending.sentAt>=timeout&&!locked){locked=true;adapter.result({requestId:pending.requestId,status:'uncertain',message:'No confirmed outcome. Check AWBW and reload its tab before sending more orders.'});}}
 function status(){tick();const state=adapter.state();return {enabled,revision,busy:!!pending,locked,available:enabled&&!pending&&!locked&&state.available,reason:locked?'Outcome uncertain; reload the AWBW tab.':pending?'Waiting for AWBW.':!enabled?'Enable handheld orders in the AWBW bridge.':state.reason||''};}
 function guard(){tick();if(!enabled)throw new Error('Handheld orders are disabled in AWBW.');if(locked)throw new Error('Previous outcome is uncertain. Check AWBW and reload its tab.');if(pending)throw new Error('An order is already waiting for AWBW.');const state=adapter.state();if(!state.available)throw new Error(state.reason||'AWBW is not ready for orders.');return state;}
 function invalidate(){revision++;proposal=null;}
 return {
  status,
  enable(value){enabled=value===true;proposal=null;},
  cancel(){proposal=null;},
  plan(input){proposal=null;const state=guard(),prepared=adapter.prepare(input);proposal={token:id(),input:structuredClone(input),prepared,revision,version:state.version,expires:now()+60000};return {token:proposal.token,revision,expires:proposal.expires,...prepared.preview,choices:prepared.choices.map(c=>({key:c.key,label:c.label}))};},
  commit({requestId,token,choice}){
   if(typeof requestId!=='string'||!/^[a-zA-Z0-9-]{8,80}$/.test(requestId)||consumed.has(requestId))throw new Error('Duplicate or invalid order request.');
   const state=guard(),p=proposal;
   if(!p||token!==p.token||p.revision!==revision||p.version!==state.version||now()>p.expires)throw new Error('Preview is stale. Select the order again.');
   const selected=p.prepared.choices.find(c=>c.key===choice);if(!selected)throw new Error('This order was not offered by AWBW.');
   // Recompute paths, ownership, funds and eligibility immediately before sending.
   const fresh=adapter.prepare(p.input).choices.find(c=>c.key===choice);
   if(!fresh||JSON.stringify(fresh)!==JSON.stringify(selected)){proposal=null;throw new Error('AWBW state changed. Select the order again.');}
   if(consumed.size>=1000)throw new Error('Reload AWBW before sending more orders.');
   consumed.add(requestId);proposal=null;pending={requestId,...fresh,sentAt:now(),socket:adapter.socket(),interference:false};
   // A synchronous send error has an uncertain outcome too: never automatically retry.
   try{adapter.send(fresh.command);}catch{locked=true;adapter.result({requestId,status:'uncertain',message:'Connection failed while sending. Check AWBW and reload its tab.'});return;}
   if(pending)adapter.result({requestId,status:'sent',message:'Sent once. Waiting for AWBW’s response.'});
  },
  observe(socket,direction,data){
   if(socket!==adapter.socket()&&socket!==pending?.socket)return;
   if(direction==='outgoing'){
    if(!data?.action||['LeaveRoom','Ping'].includes(data.action))return;
    invalidate();
    if(pending&&(pending.seenSend||JSON.stringify(data)!==JSON.stringify(pending.command)))pending.interference=true;
    if(pending)pending.seenSend=true;
    return;
   }
   if(!data||typeof data!=='object')return;
   const events=Object.values(data).filter(v=>v&&typeof v==='object'&&typeof v.action==='string'&&!['JoinRoom','LeaveRoom','ActivityUpdate','Ping'].includes(v.action));
   if(!events.length&&!data.err)return;
   invalidate();
   if(!pending||locked)return;
   if(pending.interference)return; // Server events have no unique order IDs.
   if(data.err){const requestId=pending.requestId;pending=null;adapter.result({requestId,status:'rejected',message:'AWBW rejected the order. Check its original page for the reason.'});return;}
   const p=pending,match=events.find(e=>{
    if(p.command.action==='Move')return e.action==='Move'&&e.unit?.units_id===p.command.unitID&&e.unit?.units_players_id===p.command.playerID;
    if(p.command.action==='Capt')return e.action==='Capt'&&e.buildingInfo?.buildings_x===p.expected.x&&e.buildingInfo?.buildings_y===p.expected.y;
    if(p.command.action==='Build')return e.action==='Build'&&e.newUnit?.units_players_id===p.command.playerID&&e.newUnit?.units_x===p.expected.x&&e.newUnit?.units_y===p.expected.y&&e.newUnit?.units_name===p.expected.name;
    return p.command.action==='End'&&e.action==='NextTurn'&&Number.isInteger(e.nextPId)&&e.nextPId!==p.command.playerID;
   });
   if(match){pending=null;adapter.result({requestId:p.requestId,status:'observed',action:match.action,message:match.trapped?'AWBW returned a trapped movement outcome. Review the updated board.':'AWBW returned the matching game event. Review the updated board.'});}
  },
  disconnect(socket){if(socket!==adapter.socket()&&socket!==pending?.socket)return;invalidate();if(pending){locked=true;adapter.result({requestId:pending.requestId,status:'uncertain',message:'Connection interrupted. Check AWBW and reload its tab; do not repeat the order.'});}}
 };
}

// Adapter for the reviewed official frontend. No guessed terrain/combat rules.
function createOfficialAdapter(w, {observed, visibleUnits, result}) {
 const viewer=()=>typeof w.getViewerPId==='function'?w.getViewerPId():null;
 const buildingList=()=>Object.values(w.buildingsInfo||{}).flatMap(column=>Object.values(column||{}));
 function state(){
  const player=viewer(),width=w.maxX,height=w.maxY;
  let reason='';
  if(!Number.isInteger(player)||player<=0||w.currentTurn!==player)reason='It is not your active AWBW turn.';
  else if(!w.webSocket||!observed.has(w.webSocket)||w.webSocket.readyState!==1)reason='AWBW’s observed connection is not ready. Reload the AWBW tab.';
  else if(w.gameEndDate||w.freezeGame!==false)reason='Game ended or replay mode is active.';
  else if(w.ongoingAction!==false||!Array.isArray(w.actionQueue)||w.actionQueue.length)reason='Wait for AWBW to finish updating the board.';
  else if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width>128||height>128||!w.unitsInfo||!w.playersInfo?.[player]||!Number.isFinite(Number(w.playersInfo[player].players_funds)))reason='Official game state is incomplete.';
  else if(!['emitData','getMovementTiles','findShortestPath','checkTargetTile','findCostMultiplier'].every(k=>typeof w[k]==='function'))reason='AWBW’s rule helpers changed; this version cannot submit orders.';
  const ownUnits=Object.values(w.unitsInfo||{}).filter(u=>u.units_players_id===player).map(u=>[u.units_id,u.units_x,u.units_y,u.units_moved,u.units_fuel,u.units_hit_points,u.units_ammo]);
  const ownBuildings=buildingList().filter(b=>b.buildings_players_id===player).map(b=>[b.buildings_id,b.buildings_x,b.buildings_y,b.buildings_capture]);
  return {available:!reason,reason,version:JSON.stringify([w.currentTurn,w.gameDay,w.clientLastUpdated,w.playersInfo?.[player]?.players_funds,ownUnits,ownBuildings])};
 }
 function at(x,y){if(!Number.isInteger(x)||!Number.isInteger(y)||x<0||y<0||x>=w.maxX||y>=w.maxY)throw new Error('Tile is outside the AWBW map.');}
 function prepare(input){
  if(!input||typeof input!=='object')throw new Error('Invalid preview request.');
  const player=viewer(),ready=state();if(!ready.available)throw new Error(ready.reason);
  if(input.kind==='end')return {preview:{kind:'end',summary:'End your real AWBW turn'},choices:[{key:'End',label:'End AWBW turn',command:{action:'End',playerID:player},expected:{}}]};
  if(input.kind==='build'){
   at(input.x,input.y);const b=w.buildingsInfo?.[input.x]?.[input.y],p=w.playersInfo[player];
   if(!b||b.buildings_players_id!==player||w.unitMap?.[input.x]?.[input.y])throw new Error('Choose an empty production property you own.');
   const name=b.terrain_name,types=/Base/.test(name)||(/City/.test(name)&&p.co_name==='Hachi'&&p.players_co_power_on==='S')?['F','B','T','W','P']:/Airport/.test(name)?['A']:/Port/.test(name)?['L','S']:null;
   if(!types||!w.genericUnits)throw new Error('This property cannot build units.');
   const multiplier=w.findCostMultiplier(player),funds=Number(p.players_funds);if(!Number.isFinite(multiplier)||multiplier<=0)throw new Error('Unknown AWBW purchase cost.');
   const choices=[];
   for(const [key,u] of Object.entries(w.genericUnits)){
    if(w.banUnits?.[key]||!types.includes(u.units_movement_type)||w.labUnits?.[key]&&p.labs===0||w.labUnits?.[u.units_name]&&p.labs===0)continue;
    const cost=u.units_cost*multiplier;
    if(!Number.isInteger(u.units_id)||u.units_id<=0||!Number.isFinite(cost)||cost<0||cost>funds||typeof u.units_name!=='string'||!/^[A-Za-z .-]{1,24}$/.test(u.units_name))continue;
    choices.push({key:`Build:${u.units_id}`,label:`${u.units_name} · ${cost.toLocaleString()} G`,command:{action:'Build',playerID:player,unitID:u.units_id,buildingID:b.buildings_id},expected:{x:input.x,y:input.y,name:u.units_name,cost}});
   }
   choices.sort((a,b)=>a.expected.cost-b.expected.cost);
   return {preview:{kind:'build',x:input.x,y:input.y,summary:`Build at tile ${input.x+1}, ${input.y+1}`},choices};
  }
  if(input.kind!=='unit'||!Number.isInteger(input.unitId))throw new Error('Unsupported order.');
  const u=w.unitsInfo[input.unitId];
  if(!u||u.units_players_id!==player||u.units_moved!==0||!visibleUnits().some(v=>v.id===input.unitId))throw new Error('Select a visible, ready unit you own.');
  const old=w.currentClick;
  try {
   w.currentClick={info:u,path:[u.units_y*w.maxX+u.units_x]};
   const solved=w.getMovementTiles(w.maxX,w.maxY,u.units_movement_type,Math.min(u.units_movement_points,u.units_fuel),{x:u.units_x,y:u.units_y},w.playersInfo[player].players_team,w.playersInfo[player],false);
   if(!Array.isArray(solved?.dist)||solved.dist.length!==w.maxX*w.maxY)throw new Error('Unexpected AWBW movement result.');
   const reachable=[];solved.dist.forEach((d,n)=>{const x=n%w.maxX,y=Math.floor(n/w.maxX),occupant=w.unitMap?.[x]?.[y];if(Number.isFinite(d)&&(!occupant||occupant.units_id===u.units_id))reachable.push(n);});
   const preview={kind:'unit',unitId:u.units_id,name:u.units_name,from:{x:u.units_x,y:u.units_y},reachable,summary:`Select a destination for ${u.units_name}`};
   if(input.x===undefined&&input.y===undefined)return {preview,choices:[]};
   at(input.x,input.y);if(!reachable.includes(input.y*w.maxX+input.x))throw new Error('That destination is not offered by AWBW.');
   const path=w.findShortestPath(solved,input.y*w.maxX+input.x);
   if(!Array.isArray(path)||!path.length||path[0]!==u.units_y*w.maxX+u.units_x||path.at(-1)!==input.y*w.maxX+input.x||path.length>w.maxX*w.maxY||path.some((n,i)=>!Number.isInteger(n)||n<0||n>=w.maxX*w.maxY||(i&&Math.abs(n%w.maxX-path[i-1]%w.maxX)+Math.abs(Math.floor(n/w.maxX)-Math.floor(path[i-1]/w.maxX))!==1)))throw new Error('This path needs original AWBW controls (for example, teleport movement).');
   w.currentClick.path=path;
   const options=w.checkTargetTile(input.x,input.y),choices=[];
   for(const [option,action,label] of [['Wait','Move','Wait'],['Capt','Capt','Capture']]){
    if(!options?.some(o=>o.option===option&&o.clickable===true))continue;
    const b=w.buildingsInfo?.[input.x]?.[input.y];
    choices.push({key:action,label,command:{action,path,playerID:player,unitID:u.units_id},expected:{x:input.x,y:input.y,...(action==='Capt'?{buildingId:b?.buildings_id}: {})}});
   }
   return {preview:{...preview,x:input.x,y:input.y,path,summary:`${u.units_name}: tile ${u.units_x+1}, ${u.units_y+1} → ${input.x+1}, ${input.y+1}`},choices};
  } finally {w.currentClick=old;}
 }
 return {state,prepare,socket:()=>w.webSocket,send:command=>w.emitData(w.webSocket,command),result};
}
;return {createOrderGate,createOfficialAdapter};})();

const FC_HANDHELD_HTML="";
const FC_LOBBY=(()=>{function mountLobby(css) {
 const origin=location.origin;
 const parse=doc=>{const found=new Map();for(const a of doc.querySelectorAll('a[href]')){try{const u=new URL(a.getAttribute('href'),origin),id=u.searchParams.get('games_id');if(u.origin!==origin||u.pathname!=='/game.php'||!/^\d+$/.test(id||''))continue;let name=a.textContent.trim().replace(/\s+/g,' ');if(!name||/^(view|play|game|\d+)$/i.test(name))name=`Game #${id}`;if(!found.has(id))found.set(id,{id,name,url:u.href});}catch{}}return [...found.values()];};
 function mount(){
  const overflow=document.body.style.overflow;document.body.style.overflow='hidden';
  let viewport=document.querySelector('meta[name="viewport"]'),madeViewport=!viewport,oldViewport=viewport?.getAttribute('content');if(!viewport){viewport=document.createElement('meta');viewport.name='viewport';document.head.append(viewport);}viewport.content='width=device-width,initial-scale=1,viewport-fit=cover';
  const host=document.createElement('div');host.id='fc-lobby';host.style.cssText='position:fixed;inset:0;z-index:2147483640;overflow:auto;background:#182338';const root=host.attachShadow({mode:'open'});
  const style=document.createElement('style');style.textContent=css+'\n:host{font:14px monospace;color:#e5ecd0}.lobby{max-width:680px;margin:0 auto;padding:20px}.lobby h1{font-size:24px;color:#f4d981}.games{display:grid;gap:12px;margin:20px 0}.game-link{display:block;color:#e5ecd0;border:2px solid #789b77;border-radius:6px;padding:18px;text-decoration:none;background:#203746;min-height:44px}.game-link strong{display:block;font-size:18px;margin:8px 0}.game-link small{color:#acd57e}.actions{display:flex;gap:14px;flex-wrap:wrap}.actions a{color:#f4d981;min-height:44px}.actions button{font:inherit;color:#e5ecd0;background:#263d49;border:1px solid #789b77;padding:10px;min-height:44px}';root.append(style);
  const panel=document.createElement('main');panel.className='lobby';panel.innerHTML='<header class="game-header"><div class="game-logo">FIELD<span>COMMAND</span></div><span>AWBW</span></header><h1>Choose your battlefield</h1><p>Your AWBW account · Your multiplayer games</p><div class="actions"><button id="refresh">Refresh games</button><a href="/">Account & lobby ↗</a><button id="original">Original AWBW</button></div><p id="status" role="status">Reading your game list…</p><div class="games" id="games"></div>';root.append(panel);document.body.append(host);
  const message=root.querySelector('#status'),list=root.querySelector('#games');let generation=0;
  function show(games,turns){list.replaceChildren();for(const game of games){const a=document.createElement('a');a.className='game-link';a.href=`${origin}/game.php?games_id=${game.id}`;const badge=document.createElement('small');badge.textContent=turns?.has(game.id)?'▶ YOUR TURN':turns?'WAITING':'AWBW GAME';const title=document.createElement('strong');title.textContent=game.name;const label=document.createElement('span');label.textContent=`#${game.id} · Open battlefield →`;a.append(badge,title,label);list.append(a);}message.textContent=games.length?`${games.length} games${turns?` · ${games.filter(g=>turns.has(g.id)).length} awaiting your move`:''}`:'No games found. Use Account & lobby to sign in or check your AWBW account.';}
  async function read(url){const response=await fetch(url,{credentials:'same-origin',signal:AbortSignal.timeout(15000)});if(!response.ok||new URL(response.url).origin!==origin||new URL(response.url).pathname!=='/yourgames.php')throw new Error('Open AWBW to sign in, then return to Your Games.');return parse(new DOMParser().parseFromString(await response.text(),'text/html'));}
  async function refresh(){const g=++generation;message.textContent='Reading your game list…';const [all,turn]=await Promise.allSettled([read('/yourgames.php'),read('/yourgames.php?yourTurn=1')]);if(g!==generation)return;show(all.status==='fulfilled'?all.value:parse(document),turn.status==='fulfilled'?new Set(turn.value.map(v=>v.id)):null);if(all.status==='rejected')message.textContent=all.reason.message;}
  root.querySelector('#refresh').onclick=refresh;root.querySelector('#original').onclick=()=>{generation++;host.remove();document.body.style.overflow=overflow;if(madeViewport)viewport.remove();else if(oldViewport===null)viewport.removeAttribute('content');else viewport.content=oldViewport;};refresh();
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
}
;return{mount:()=>mountLobby(":root{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;color:#edf2d8;background:#101929;font-synthesis:none;--tile:32px;--scale:2;--ink:#182338;--gold:#f9d873;--blue:#344d70}*{box-sizing:border-box}body{margin:0}button,a,label{-webkit-tap-highlight-color:transparent}button{font:inherit;cursor:pointer;color:inherit}button:focus-visible,a:focus-visible{outline:3px solid #ffe8a0;outline-offset:2px}button:disabled{opacity:.4;cursor:default}a{color:inherit;text-decoration:none}.game-app{max-width:1080px;margin:auto;min-height:100dvh;background:#23344e;border:1px solid #41516a;display:flex;flex-direction:column}.game-header{display:flex;align-items:center;justify-content:space-between;padding:18px 24px;background:#182338;border-bottom:3px solid #101b2b;gap:12px}.game-logo{font-size:14px;font-weight:900;letter-spacing:2px;line-height:1.1;color:var(--gold)}.game-logo span{display:block;color:#e7edd5;font-size:11px;letter-spacing:1.5px}.game-mode{font-size:9px;letter-spacing:1px;color:#bdd3cf;background:#253a4e;padding:7px 10px;border:1px solid #4c647a}.pill{padding:9px 13px;border:1px solid #6a7a91;background:#314763;font-size:10px}.commander-bar{display:flex;align-items:center;gap:12px;padding:15px 24px;background:linear-gradient(90deg,#df7b43,#ad5039);border-top:2px solid #ffa66b;border-bottom:3px solid #582a2d;text-shadow:1px 2px #632d2a}.commander-bar.green{background:linear-gradient(90deg,#689c54,#3f724a);border-top-color:#a5c178;border-bottom-color:#2e4532;text-shadow:1px 2px #254328}.commander-bar img{width:48px;height:48px;image-rendering:pixelated;background:#6a473e;border:2px solid #ffe5a4;object-fit:contain}.commander-bar>div>span{display:block;font-size:9px;letter-spacing:1.7px;margin-bottom:6px}.commander-bar>div>strong{font-size:16px;letter-spacing:1px}.turn-info{margin-left:auto;text-align:right}.turn-info strong{color:#ffedb5}.battle-space{position:relative;padding:20px 24px 10px;background:#121e2e;flex:1}.map-scroll{overflow:auto;max-height:58dvh;min-height:300px;overscroll-behavior:contain;touch-action:pan-x pan-y;position:relative;background:#17281e;border:3px solid #506249;box-shadow:0 0 0 2px #090f18;scrollbar-color:#587447 #273d29}.map{display:grid;grid-template-columns:repeat(var(--cols),var(--tile));width:max-content;margin:0 auto;position:relative;isolation:isolate;padding:0;background:#81955a;gap:0}.map-cell{position:relative;width:var(--tile);height:var(--tile);border:0;background:#8c9f60;padding:0;overflow:visible;touch-action:manipulation}.map-cell img{image-rendering:pixelated;position:absolute;left:0;bottom:0;width:100%;height:auto;pointer-events:none}.map-cell .crop{position:absolute;width:16px;height:16px;left:0;bottom:0;transform:scale(var(--scale));transform-origin:bottom left;background-repeat:no-repeat;image-rendering:pixelated;pointer-events:none}.map-cell .unit{z-index:3}.map-cell .spent{filter:grayscale(.8) brightness(.7)}.map-cell .health{position:absolute;bottom:0;right:0;z-index:4;font-size:calc(var(--tile)*.28);color:#fff;text-shadow:1px 1px #111;background:#15271bd9;padding:0 2px;pointer-events:none}.map-cell.reachable:after{content:'';position:absolute;inset:1px;background:#fffba544;border:1px solid #fff5ae77;z-index:5;pointer-events:none}.map-cell.target:after{content:'';position:absolute;inset:2px;border:2px solid #f5524b;z-index:5;pointer-events:none}.map-cell.cursor{z-index:6}.map-cell.cursor:before{content:'';position:absolute;inset:0;border:2px solid #fff5b6;box-shadow:inset 0 0 0 1px #1d311a,0 0 0 1px #213420;z-index:7;pointer-events:none}.map-cell.unknown{background:repeating-conic-gradient(#4a565b 0 25%,#687279 0 50%) 0/16px 16px}.map-cell .live-layer{position:absolute;pointer-events:none;image-rendering:pixelated;transform:scale(var(--scale));transform-origin:bottom left;left:0;bottom:0;background-repeat:no-repeat}.map-tools{position:absolute;right:35px;top:30px;display:flex;align-items:center;background:#172833ef;border:1px solid #61797c;z-index:10;box-shadow:2px 2px #1118}.map-tools button{width:34px;height:34px;background:none;border:0;font-size:20px}.map-tools span{font-size:10px;padding:0 6px}.map-caption{display:flex;justify-content:space-between;padding:12px 0 2px;font-size:8px;letter-spacing:1px;color:#a5b5b1;gap:12px}.orders{padding:15px 24px;background:#e4e4c8;color:#273d40;border-top:3px solid #f8f1d5;border-bottom:4px solid #939c82;min-height:170px}.selection-info{display:flex;gap:13px;align-items:center}.terrain-preview{width:50px;height:50px;flex-shrink:0;background:#b4c094;border:2px solid #6b8061;position:relative;overflow:hidden}.terrain-preview img{width:100%;height:auto;image-rendering:pixelated;position:absolute;bottom:0;left:0}.selection-info span{font-size:9px;letter-spacing:1px;display:block}.selection-info strong{font-size:16px;display:block;margin-top:4px}.selection-info p{font-size:9px;color:#617272;margin:6px 0;line-height:1.5}.back-button{margin-left:auto;flex-shrink:0;width:35px;height:35px;background:#5d617a;border:2px solid #b4b5c4;border-radius:50%;box-shadow:0 2px #3c4257;color:#fff1dd;font-weight:bold}.commands{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}.commands button{padding:10px 15px;min-height:44px;background:#36556b;border:2px solid #7190a0;box-shadow:0 2px #213a4b;color:#fff1cc;font-size:11px;font-weight:bold;letter-spacing:.5px}.commands button.primary{background:#b56539;border-color:#e5a268;box-shadow:0 2px #6c3a27}.message{font-size:10px;color:#4a6262;margin:12px 0 0;line-height:1.5}.game-footer{display:flex;align-items:center;justify-content:space-between;padding:16px 35px max(16px,env(safe-area-inset-bottom));background:linear-gradient(110deg,#374964,#23364f);gap:15px}.dpad{display:grid;grid-template-columns:repeat(3,28px);grid-template-rows:repeat(3,24px)}.dpad button,.dpad i{border:0;background:#16253b;display:grid;place-items:center;color:#8a9ba9;box-shadow:0 2px #0c1525;font-size:10px;font-style:normal}.dpad [data-dir=up]{grid-column:2;border-radius:3px 3px 0 0}.dpad [data-dir=left]{grid-row:2;border-radius:3px 0 0 3px}.dpad i{grid-row:2;grid-column:2}.dpad [data-dir=right]{grid-row:2;grid-column:3;border-radius:0 3px 3px 0}.dpad [data-dir=down]{grid-row:3;grid-column:2;border-radius:0 0 3px 3px}.a-button{width:54px;height:54px;border-radius:50%;background:#993e52;border:2px solid #d88891;box-shadow:0 4px #452538;font-size:25px;font-weight:bold}.footer-note{text-align:center}.footer-note span{display:block;color:#e1d59e;letter-spacing:1.5px;font-size:10px}.footer-note small{display:block;font-size:8px;color:#8fa8b7;margin-top:8px}dialog{background:#e4e4c8;color:#253b43;border:4px solid #7591a0;box-shadow:0 0 0 4px #172c3e;padding:22px;width:min(420px,90vw)}dialog::backdrop{background:#081524c9;backdrop-filter:blur(3px)}.dialog-heading{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}.dialog-heading h2{font-size:17px}.dialog-heading button{border:0;background:none;font-size:26px}dialog>button,dialog>a,.file-button{display:block;width:100%;text-align:left;background:#344f65;color:#f3ebc9;padding:13px;border:1px solid #6f91a0;margin:9px 0;font:12px ui-monospace,monospace;cursor:pointer}.file-button input{display:none}dialog p{font-size:10px;line-height:1.7;color:#637575}.hidden{display:none!important}@media(min-width:900px){.game-app{margin:25px auto;min-height:calc(100dvh - 50px);border-radius:14px;overflow:hidden;box-shadow:0 10px 60px #0005}.map-scroll{max-height:55vh}.game-header{padding:20px 30px}.commander-bar{padding:15px 30px}.battle-space{padding:20px 30px 10px}.orders{padding:18px 30px}.map-tools{right:40px}.game-footer{padding-left:45px;padding-right:45px}}@media(max-width:600px){.game-header{padding:12px 15px}.game-logo{font-size:11px}.game-logo span{font-size:9px}.game-mode{font-size:7px;padding:6px}.pill{font-size:9px;padding:8px}.commander-bar{padding:12px 15px;gap:9px}.commander-bar img{width:40px;height:40px}.commander-bar>div>strong{font-size:12px}.commander-bar>div>span{font-size:8px}.battle-space{padding:12px 12px 8px}.map-scroll{max-height:43dvh;min-height:230px}.map-tools{right:23px;top:22px}.map-tools button{width:30px;height:30px}.map-caption{font-size:6px;letter-spacing:.3px;padding-top:9px}.orders{padding:12px 15px;min-height:175px}.selection-info strong{font-size:14px}.commands button{font-size:10px;padding:9px 13px}.game-footer{padding:12px 24px max(12px,env(safe-area-inset-bottom))}.footer-note small{font-size:7px;max-width:145px;line-height:1.7}.footer-note span{font-size:8px}.message{font-size:9px}}@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important}}\n\n.map-cell.raster{background:transparent}\n\n.map{image-rendering:pixelated}.terrain-preview{image-rendering:pixelated}\n\n.map-cell.path-preview{box-shadow:inset 0 0 0 3px #ffd659;z-index:2}\n")};})();

(() => {
'use strict';
if(window.top!==window.self||window.__fieldCommandBridge)return;
window.__fieldCommandBridge=true;
if(location.pathname==='/yourgames.php'){FC_LOBBY.mount();return;}
const contracts=[];
const observedSockets=new WeakSet();let orderGate;
function path(raw){try{const u=new URL(raw,location.href);return u.origin===location.origin?u.pathname:null;}catch{return null;}}
function fields(body){try{if(body instanceof FormData||body instanceof URLSearchParams)return [...new Set(body.keys())].slice(0,60);if(typeof body==='string'){if(body.trim().startsWith('{'))return Object.keys(JSON.parse(body)).slice(0,60);return [...new Set(new URLSearchParams(body).keys())].slice(0,60);}}catch{}return [];}
function record(url,method,status,keys,responseSchema,requestExample,responseExample){const endpoint=path(url);if(!endpoint)return;const queryFieldNames=[...new Set(new URL(url,location.href).searchParams.keys())].slice(0,60);contracts.push({path:endpoint,method:String(method||'GET').toUpperCase(),status,requestFieldNames:keys,queryFieldNames,responseSchema:responseSchema||null,requestSample:requestExample||{},responseSample:responseExample??null,evidence:'observed-official-page; independent client not tested'});if(contracts.length>150)contracts.shift();}
// Observe requests already issued by AWBW; never initiate an action request.
const originalFetch=window.fetch;
window.fetch=function(input,init){const result=originalFetch.apply(this,arguments);const raw=typeof input==='string'||input instanceof URL?String(input):input.url;const method=init?.method||(input instanceof Request?input.method:'GET'),keys=fields(init?.body),requestExample=FC_INSPECTION.requestSample(init?.body,raw);result.then(response=>{const mime=response.headers.get('content-type')||'';if(mime.includes('json'))response.clone().text().then(text=>{let shape=null,sample=null;try{if(text.length<200000){const data=JSON.parse(text);shape=FC_INSPECTION.schema(data);sample=FC_INSPECTION.responseSample(data);}}catch{}record(raw,method,response.status,keys,shape,requestExample,sample);}).catch(()=>record(raw,method,response.status,keys,null,requestExample));else record(raw,method,response.status,keys,null,requestExample);},()=>record(raw,method,0,keys,null,requestExample));return result;};
const open=XMLHttpRequest.prototype.open,send=XMLHttpRequest.prototype.send,requests=new WeakMap();
XMLHttpRequest.prototype.open=function(method,url){requests.set(this,{method,url});return open.apply(this,arguments);};
XMLHttpRequest.prototype.send=function(body){const info=requests.get(this);if(info)this.addEventListener('loadend',()=>{let shape=null,sample=null;try{const data=this.responseType==='json'?this.response:(this.getResponseHeader('content-type')||'').includes('json')&&this.responseText.length<200000?JSON.parse(this.responseText):null;if(data!==null){shape=FC_INSPECTION.schema(data);sample=FC_INSPECTION.responseSample(data);}}catch{}record(info.url,info.method,this.status,fields(body),shape,FC_INSPECTION.requestSample(body,info.url),sample);},{once:true});return send.apply(this,arguments);};
// AWBW's official client sends orders through WebSocket (game.js emitData).
// Reuse the original socket only after opt-in and a confirmed, validated proposal.
const NativeWebSocket=window.WebSocket;
if(NativeWebSocket){
 const nativeSend=NativeWebSocket.prototype.send;
 function socketEvidence(socket,direction,payload){try{if(typeof payload!=='string'||payload.length>200000)return;const data=JSON.parse(payload);if(!data||typeof data!=='object')return;orderGate?.observe(socket,direction,data);const url=new URL(socket.url);contracts.push({transport:'websocket',path:url.pathname,direction,method:direction==='outgoing'?'WS_SEND':'WS_RECEIVE',status:null,requestFieldNames:direction==='outgoing'?Object.keys(data):[],requestSample:direction==='outgoing'?FC_INSPECTION.requestSample(JSON.stringify(data),'https://awbw.amarriner.com/'):{},responseSchema:direction==='incoming'?FC_INSPECTION.schema(data):null,responseSample:direction==='incoming'?FC_INSPECTION.responseSample(data):null,evidence:'observed-official-websocket; not an independently verified order'});if(contracts.length>150)contracts.shift();}catch{}}
 NativeWebSocket.prototype.send=function(payload){socketEvidence(this,'outgoing',payload);return nativeSend.apply(this,arguments);};
 function attachSocket(socket){if(observedSockets.has(socket))return;observedSockets.add(socket);socket.addEventListener('message',event=>socketEvidence(socket,'incoming',event.data));socket.addEventListener('close',()=>{orderGate?.disconnect(socket);sendCapabilities();});}
 window.WebSocket=new Proxy(NativeWebSocket,{construct(Target,args){const socket=Reflect.construct(Target,args);attachSocket(socket);return socket;}});
 // Some phone managers inject after page scripts. Attach to the existing official socket too.
 window.__fcAttachExisting=()=>{try{const socket=window.webSocket,url=new URL(socket?.url),id=new URL(location.href).searchParams.get('games_id');if(socket instanceof NativeWebSocket&&url.protocol==='wss:'&&url.pathname.endsWith('/game/'+id))attachSocket(socket);}catch{}};
 window.__fcAttachExisting();
}
let embedded=null;
let host,ui,status,client=null,clientOrigin='',timer,observer,lastError='',lastSent='',connected=false;
const unitPattern=/(?:^|\/)(?:aa|ab|ar|bd|bh|bm|ci|ge|gs|js|ne|os|pc|pl|rf|sc|tg|uw|wn|yc)(?:infantry|mech|tank|md\.tank|neotank|megatank|recon|apc|artillery|rocket|missile|anti-air|b-copter|t-copter|fighter|bomber|stealth|lander|cruiser|battleship|sub|carrier|blackboat|blackbomb|piperunner)\.(gif|png)$/i;
function sourceUrl(raw){try{const u=new URL(raw,location.href);if(u.origin!==location.origin||!u.pathname.startsWith('/terrain/')||!/\.(gif|png|webp|jpe?g)$/i.test(u.pathname))return null;u.search='';u.hash='';return u.href;}catch{return null;}}
function visible(node){const r=node.getBoundingClientRect(),style=getComputedStyle(node);if(!r.width||!r.height||style.display==='none'||style.visibility==='hidden'||Number(style.opacity)===0)return false;for(let p=node.parentElement;p&&p!==document.body;p=p.parentElement){const s=getComputedStyle(p);if(s.display==='none'||s.visibility==='hidden'||Number(s.opacity)===0)return false;}return true;}
function candidates(){const out=[];for(const node of document.querySelectorAll('img,[style],[class*="terrain"],[class*="tile"]')){if(host?.contains(node)||!visible(node))continue;const style=getComputedStyle(node),r=node.getBoundingClientRect();let source,background=false;if(node.tagName==='IMG')source=sourceUrl(node.currentSrc||node.src);else{const match=style.backgroundImage.match(/^url\(["']?(.+?)["']?\)$/);if(match){source=sourceUrl(match[1]);background=true;}}if(!source)continue;const filename=new URL(source).pathname.split('/').pop();if(!source.includes('/ani/')&&!unitPattern.test(source)&&filename!=='terrain_spritesheet.png'&&!/^(neutral|orangestar|greenearth|bluemoon).*\.gif$/i.test(filename))continue;out.push({node,r,style,source,background,kind:unitPattern.test(source)?'unit':'terrain'});}return out;}
function filters(node,root){const list=[];let opacity=1;for(let n=node;n;n=n.parentElement){const style=getComputedStyle(n);opacity*=Number(style.opacity);if(style.filter!=='none')list.push(style.filter);if(n===root)break;}return{opacity,filter:list.join(' ')};}
function normalizedCss(value,node){const factor=16/(parseFloat(node.style.width)||16);return value.replace(/(-?\d+(?:\.\d+)?)px/g,(_,n)=>`${Number(n)*factor}px`);}
function visibleGameState(root,width,height){
 const result={readOnly:true,canSendOrders:false,viewerPlayerId:null,currentPlayerId:null,funds:null,units:[],buildings:[]};
 try{const viewer=typeof window.getViewerPId==='function'?window.getViewerPId():window.viewerPId;result.viewerPlayerId=Number.isInteger(Number(viewer))&&Number(viewer)>0?Number(viewer):null;result.currentPlayerId=Number.isInteger(Number(window.currentTurn))&&Number(window.currentTurn)>0?Number(window.currentTurn):null;result.funds=Number.isFinite(Number(window.playersInfo?.[result.viewerPlayerId]?.players_funds))?Number(window.playersInfo[result.viewerPlayerId].players_funds):null;const fog=document.querySelector('#fog-canvas'),fogCtx=fog?.getContext('2d');
 for(const column of Object.values(window.buildingsInfo||{}))for(const b of Object.values(column||{})){if(b.buildings_players_id!==result.viewerPlayerId)continue;const x=b.buildings_x,y=b.buildings_y;if(!Number.isInteger(b.buildings_id)||!Number.isInteger(x)||!Number.isInteger(y)||x<0||y<0||x>=width||y>=height)continue;result.buildings.push({id:b.buildings_id,owner:b.buildings_players_id,x,y,name:typeof b.terrain_name==='string'?b.terrain_name.slice(0,40):'Property'});}
 for(const span of root.querySelectorAll('.game-unit[data-unit-id]')){if(!visible(span))continue;const unit=window.unitsInfo?.[span.dataset.unitId];if(!unit)continue;const x=Number(unit.units_x),y=Number(unit.units_y),id=Number(unit.units_id),owner=Number(unit.units_players_id);if(![id,owner,x,y].every(Number.isInteger)||x<0||y<0||x>=width||y>=height)continue;
 let z=0;for(let n=span;n&&n!==root;n=n.parentElement){const value=getComputedStyle(n).zIndex;if(value!=='auto'){z=Number(value)||0;break;}}
 if(fogCtx&&visible(fog)&&z<104){try{if(fogCtx.getImageData(x*16+8,y*16+8,1,1).data[3]>0)continue;}catch{continue;}}
 const numeric=(value,max)=>value!==null&&value!==undefined&&value!==''&&Number.isFinite(Number(value))&&Number(value)>=0&&Number(value)<=max?Number(value):null;
 const name=typeof unit.units_name==='string'&&/^[A-Za-z .-]{1,24}$/.test(unit.units_name)?unit.units_name:'Visible unit';
 result.units.push({id,owner,x,y,name,hp:numeric(unit.units_hit_points,10),fuel:numeric(unit.units_fuel,999),ammo:numeric(unit.units_ammo,99),spent:unit.units_moved===1});
 }
 }catch{/* Missing globals leave unit details unavailable, not guessed. */}
 return result;
}
function officialFrame(){
 const root=document.querySelector('#gamemap'),ground=document.querySelector('canvas#map-background');
 if(!root||!ground)return null;
 if(!ground.width||!ground.height||ground.width%16||ground.height%16)throw new Error('Unexpected AWBW terrain canvas dimensions.');
 const width=ground.width/16,height=ground.height/16;if(width>128||height>128)throw new Error('AWBW map is too large.');
 const canvas=document.createElement('canvas');canvas.width=ground.width;canvas.height=ground.height;const ctx=canvas.getContext('2d');ctx.imageSmoothingEnabled=false;
 const origin=ground.getBoundingClientRect(),sx=ground.width/origin.width,sy=ground.height/origin.height;
 function zIndex(node){for(let n=node;n&&n!==root;n=n.parentElement){const z=getComputedStyle(n).zIndex;if(z!=='auto')return Number(z)||0;}return 0;}
 const nodes=[...root.querySelectorAll('canvas,img')].filter(n=>visible(n)&&(!n.closest('.unit-options-game,.build-options-game')||n===ground)).sort((a,b)=>zIndex(a)-zIndex(b));
 for(const node of nodes){const r=node.getBoundingClientRect();if(node.tagName==='IMG'&&(!node.complete||!node.naturalWidth))continue;const effect=filters(node,root);ctx.globalAlpha=effect.opacity;ctx.filter=effect.filter||'none';try{ctx.drawImage(node,(r.left-origin.left)*sx,(r.top-origin.top)*sy,r.width*sx,r.height*sy);}catch{}}
 const frame=canvas.toDataURL('image/png');if(frame.length>4000000)throw new Error('Rendered map exceeds snapshot size limit.');
 return{format:'field-command-snapshot-v2',gameId:new URL(location.href).searchParams.get('games_id'),title:`AWBW #${new URL(location.href).searchParams.get('games_id')}`,day:Number(document.body.innerText.match(/\bDay\s+(\d+)/i)?.[1])||null,game:visibleGameState(root,width,height),capturedAt:new Date().toISOString(),map:{width,height,tileSize:16,layers:[],frame},coverage:{renderedOnly:true,warning:'Read-only pixel mirror of the original map canvas, fog, and visible sprites. Order eligibility is checked in the original AWBW tab.'}};
}
function snapshot(){const official=officialFrame();if(official)return official;const all=candidates();if(all.length<12)throw new Error('Not enough rendered map sprites found. Let the map finish loading.');const groups=new Map();for(const c of all){let parent=c.node.parentElement;for(let d=0;parent&&d<7;d++,parent=parent.parentElement){if(parent===document.body||parent===document.documentElement)break;const r=parent.getBoundingClientRect();if(r.width<100||r.height<80||r.width>3000||r.height>3000)continue;if(!groups.has(parent))groups.set(parent,[]);groups.get(parent).push(c);}}
let best=null,score=0;for(const[node,items]of groups){if(items.length<12)continue;const r=node.getBoundingClientRect();const widths=items.map(c=>Math.round(c.r.width));const counts=new Map();widths.forEach(w=>counts.set(w,(counts.get(w)||0)+1));const tile=[...counts].sort((a,b)=>b[1]-a[1])[0][0];if(tile<8||tile>128)continue;const cells=r.width*r.height/(tile*tile);const density=Math.min(1,items.length/Math.max(1,cells));const value=items.length*(.25+density);if(value>score){score=value;best={node,items,tile};}}
if(!best)throw new Error('Could not identify a map container. Export inspection so the adapter can be adjusted.');
const {items,tile}=best,left=Math.min(...items.map(c=>c.r.left)),top=Math.min(...items.map(c=>c.r.bottom))-tile;
const layers=items.map(c=>{const effect=filters(c.node,best.node);return{x:Math.round((c.r.left-left)/tile),y:Math.round((c.r.bottom-top)/tile)-1,source:c.source,kind:c.kind,width:c.r.width/tile*16,height:c.r.height/tile*16,background:c.background,backgroundPosition:normalizedCss(c.style.backgroundPosition,c),backgroundSize:normalizedCss(c.style.backgroundSize,c),opacity:effect.opacity,filter:effect.filter,locator:{tag:c.node.tagName,id:c.node.id.slice(0,80),classes:String(c.node.className||'').slice(0,120)}};}).filter(l=>l.x>=0&&l.y>=0);
const width=Math.max(...layers.map(l=>l.x))+1,height=Math.max(...layers.map(l=>l.y))+1;if(width>128||height>128)throw new Error('Detected map is too large; original page structure needs inspection.');
const gameId=new URL(location.href).searchParams.get('games_id');if(!/^\d+$/.test(gameId||''))throw new Error('This is not a game page.');const text=document.body.innerText,day=Number(text.match(/\bDay\s+(\d+)/i)?.[1])||null;
return{format:'field-command-snapshot-v1',gameId,title:`AWBW #${gameId}`,day,capturedAt:new Date().toISOString(),map:{width,height,tileSize:tile,layers},coverage:{renderedOnly:true,warning:'Rendered sprites only. Terrain meaning, HP, ownership, fog rules, and server turn state are not yet verified.'}};}
function download(data,name){const url=URL.createObjectURL(new Blob([JSON.stringify(data,null,2)],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),10000);}
async function inspect(){status.textContent='Preparing read-only inspection…';const resources=[...new Set([...document.querySelectorAll('script[src],link[rel="stylesheet"]')].map(n=>n.src||n.href).filter(u=>path(u)&&/\.(js|css)(?:\?|$)/i.test(u)))].slice(0,30),publicFiles=[];let total=0;for(const url of resources){try{const p=path(url),response=await originalFetch.call(window,new URL(p,location.origin),{credentials:'omit',signal:AbortSignal.timeout(10000)});if(!response.ok||path(response.url)!==p||!/(javascript|ecmascript|text\/css)/i.test(response.headers.get('content-type')||''))continue;const text=await response.text();if(/^\s*<(?:!doctype|html)/i.test(text))continue;if(text.length>2000000||total+text.length>8000000)continue;total+=text.length;publicFiles.push({path:p,source:text});}catch{/* Report absent files, never retry with session credentials. */}}
let state=null,error='';try{state=snapshot();}catch(e){error=e.message;}const metadata={format:'field-command-inspection-v2',snapshot:state,snapshotError:error,capturedAt:new Date().toISOString(),contracts:contracts.slice().map((c,i)=>({...c,responseSample:c.responseSample})),publicFiles,pageStructure:{scripts:resources.map(path),mapCandidateCount:candidates().length},note:'Only whitelisted game/action sample values are included. Authentication values, arbitrary strings, headers, cookies, HTML, and inline scripts are excluded. Samples are evidence from the official client, not independent verification. Public static source files were requested without credentials.'};download(metadata,`awbw-inspection-${new URL(location.href).searchParams.get('games_id')}.json`);status.textContent=`Inspection exported. ${publicFiles.length} public source files; ${contracts.length} observed requests.${error?' Map adapter: '+error:''}`;}
function sendSnapshot(){if(!client||client.closed){connected=false;return;}try{const data=snapshot(),signature=JSON.stringify({...data,capturedAt:''});if(signature!==lastSent){client.postMessage({type:'FC_SNAPSHOT',snapshot:data},clientOrigin);lastSent=signature;}status.textContent=`AWBW mirror: ${data.map.width}×${data.map.height}. Keep this AWBW tab open.`;lastError='';}catch(e){if(e.message!==lastError){status.textContent=e.message;lastError=e.message;}}}
orderGate=FC_ORDERS.createOrderGate(FC_ORDERS.createOfficialAdapter(window,{observed:observedSockets,visibleUnits:()=>{const root=document.querySelector('#gamemap');return root?visibleGameState(root,window.maxX,window.maxY).units:[];},result:data=>{post({type:'FC_ORDER_RESULT',...data});setTimeout(()=>{sendSnapshot();sendCapabilities();},0);}}));
function post(data){if(client&&!client.closed&&clientOrigin)client.postMessage(data,clientOrigin);}
function sendCapabilities(){if(!connected)return;try{post({type:'FC_CAPABILITIES',gameId:new URL(location.href).searchParams.get('games_id'),...orderGate.status()});}catch{post({type:'FC_CAPABILITIES',available:false,enabled:false,reason:'Could not read official game state.'});}}
window.addEventListener('message',event=>{
 if(event.source!==client||event.origin!==clientOrigin||!event.data||typeof event.data!=='object')return;
 const data=event.data;
 if(data.type==='FC_READY'){orderGate.enable(true);connected=true;lastSent='';sendSnapshot();sendCapabilities();return;}
 if(!connected||data.gameId!==new URL(location.href).searchParams.get('games_id'))return;
 if(data.type==='FC_CLOSE'){if(embedded)embedded.querySelector('button').click();else{orderGate.enable(false);window.focus();}return;}
 if(data.type==='FC_CANCEL'){orderGate.cancel();return;}
 if(typeof data.requestId!=='string'||!/^[a-zA-Z0-9-]{8,80}$/.test(data.requestId))return;
 try{
  if(data.type==='FC_PLAN')post({type:'FC_PLAN_RESULT',requestId:data.requestId,plan:orderGate.plan(data.input)});
  else if(data.type==='FC_COMMIT')orderGate.commit(data);
 }catch(e){post({type:data.type==='FC_PLAN'?'FC_PLAN_RESULT':'FC_ORDER_RESULT',requestId:data.requestId,status:'blocked',message:e.message});}
 sendCapabilities();
});
function openEmbedded(){
 if(embedded)return;
 try{sessionStorage.removeItem('field-command-original');}catch{}
 orderGate.enable(false);connected=false;lastSent='';
 let viewport=document.querySelector('meta[name="viewport"]'),madeViewport=!viewport,oldViewport=viewport?.getAttribute('content');
 if(!viewport){viewport=document.createElement('meta');viewport.name='viewport';document.head.append(viewport);}viewport.content='width=device-width,initial-scale=1,viewport-fit=cover';
 embedded=document.createElement('div');embedded.id='fc-handheld';embedded.style.cssText='position:fixed;inset:0;z-index:2147483646;background:#182338';
 const frame=document.createElement('iframe');frame.title='Field Command battlefield';frame.style.cssText='border:0;width:100%;height:100%;display:block';frame.allow='fullscreen';
 const extensionUrl=document.documentElement.getAttribute('data-fc-extension-client');
 const isExtension=extensionUrl&&/^chrome-extension:\/\/[a-p]{32}\/play\.html\?live=1&embedded=1$/.test(extensionUrl);
 if(isExtension)frame.src=extensionUrl;else frame.srcdoc=FC_HANDHELD_HTML;
 const close=document.createElement('button');close.textContent='AWBW ↗';close.setAttribute('aria-label','Return to original AWBW controls');close.style.cssText='display:none';
 const overflow=document.body.style.overflow;close.onclick=()=>{try{sessionStorage.setItem('field-command-original','1');}catch{}orderGate.enable(false);orderGate.cancel();connected=false;client=null;embedded.remove();embedded=null;document.body.style.overflow=overflow;if(madeViewport)viewport.remove();else if(oldViewport===null)viewport.removeAttribute('content');else viewport.content=oldViewport;};
 embedded.append(frame,close);document.body.append(embedded);document.body.style.overflow='hidden';client=frame.contentWindow;clientOrigin=isExtension?new URL(extensionUrl).origin:location.origin;
}
function openClient(){let existing='';try{existing=localStorage.getItem('field-command-client-url')||'';}catch{}const input=prompt('Paste your Field Command site URL. Use its deployed HTTPS address, or http://localhost:5173 for local development.',existing);if(!input)return;try{const url=new URL(input);if(url.protocol!=='https:'&&!(url.protocol==='http:'&&['localhost','127.0.0.1'].includes(url.hostname)))throw new Error('Use HTTPS, or localhost for development.');url.pathname=url.pathname.replace(/(?:play|index|bridge)\.html$/,'');if(!url.pathname.endsWith('/'))url.pathname+='/';const target=new URL('play.html?live=1',url);orderGate.enable(false);connected=false;clientOrigin=target.origin;client=window.open(target.href,'field-command-live');if(!client)throw new Error('Allow this site to open the Field Command tab.');try{localStorage.setItem('field-command-client-url',url.href);}catch{}status.textContent='Opening Field Command. Keep this original tab open.';lastSent='';}catch(e){status.textContent=e.message;}}
function mount(){if(document.getElementById('fc-bridge-tool'))return;host=document.createElement('div');host.id='fc-bridge-tool';host.style.cssText='position:fixed;left:12px;bottom:12px;z-index:2147483645;max-width:calc(100vw - 24px)';ui=host.attachShadow({mode:'open'});ui.innerHTML='<style>details{font:12px system-ui;color:#edf2d8;background:#1b2e45;border:1px solid #95b6c5;border-radius:8px;max-width:335px;padding:12px;box-shadow:0 4px 25px #0005}summary{cursor:pointer;font-weight:bold;color:#f5dd91}p{line-height:1.6}button{font:inherit;min-height:44px;background:#e7da9b;color:#1b3144;border:0;border-radius:4px;padding:10px;margin:4px;cursor:pointer}button:disabled{opacity:.5}#status{font-size:11px;overflow-wrap:anywhere}</style><details><summary>Field Command · AWBW bridge</summary><p>Mirrors the visible battlefield to your Field Command site. Preview with AWBW’s own rules. Choose orders directly in the handheld view. AWBW handles the real game.</p><button id="embedded">Play handheld here</button><button id="open">Open handheld view</button><button id="snapshot">Export snapshot</button><button id="inspect">Export inspection</button><p id="status" role="status">Use the official AWBW page normally to observe its requests. No need to take extra game actions for collection. Export inspection when ready.</p></details>';document.body.append(host);status=ui.querySelector('#status');ui.querySelector('#embedded').onclick=openEmbedded;ui.querySelector('#open').onclick=openClient;ui.querySelector('#snapshot').onclick=()=>{try{download(snapshot(),`awbw-snapshot-${new URL(location.href).searchParams.get('games_id')}.json`);status.textContent='Snapshot exported.';}catch(e){status.textContent=e.message;}};ui.querySelector('#inspect').onclick=async()=>{ui.querySelector('#inspect').disabled=true;try{await inspect();}catch(e){status.textContent=e.message;}finally{ui.querySelector('#inspect').disabled=false;}};timer=setInterval(()=>{window.__fcAttachExisting?.();if(connected){sendSnapshot();sendCapabilities();}},1500);observer=new MutationObserver(()=>{if(!connected)return;clearTimeout(window.__fcBridgeDebounce);window.__fcBridgeDebounce=setTimeout(sendSnapshot,500);});observer.observe(document.body,{childList:true,subtree:true,attributes:true,attributeFilter:['src','style','class']});window.addEventListener('pagehide',()=>{clearInterval(timer);observer.disconnect();});let attempts=0;const start=setInterval(()=>{try{if(sessionStorage.getItem('field-command-original')==='1'){clearInterval(start);return;}if(snapshot().map.frame){clearInterval(start);openEmbedded();}}catch{}if(++attempts>=20)clearInterval(start);},500);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mount,{once:true});else mount();
})();

})();